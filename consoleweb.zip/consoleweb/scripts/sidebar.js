special.m = document.getElementById("main");
special.sb = document.getElementById("sidebar");
special.m.removeAttribute("id");
special.sb.removeAttribute("id");

window.special.openSidebar = function openSidebar() {
  special.sb.style.width = "250px";
  special.m.style.marginLeft = "250px";
}

window.special.closeSidebar = function closeSidebar() {
  special.sb.style.width = "";
  special.m.style.marginLeft = "";
}