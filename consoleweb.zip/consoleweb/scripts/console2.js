(function() {
    const a = document;
    const ev = eval;
    
    function q(e) {
        return a.getElementById(e)
    }
    
    const ec = q("execute"),
    it = q("input"),
    op = q("outputs"),
    cc = q("clearconsole"),
    is = q("kk");
    
    [ec, it, op, cc, is].forEach(e=>e.removeAttribute("id"));
    
    const rdo = [q("def"), q("json"), q("ps")];
    rdo.forEach(function (e) {
        e.removeAttribute("id")
    });
    rdo[0].checked = true; // select default formatting
    
    ec.addEventListener("click", function() {
        const outputsDiv = op;
        const inputVal = it.value;
        if (!inputVal) return; // no input, stop here
        
        try {
            // 1. Create a wrapper box for the user command entry
            let commandRow = a.createElement("div");
            commandRow.style.display = "flex";
            commandRow.style.alignItems = "center";
            commandRow.style.gap = "5px";
            
            // Arrow SVG
            let z = a.createElement("div");
            z.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M5.5 2L11.5 8L5.5 14L4.5 13L9.5 8L4.5 3Z" fill="#6ba1f7"></path></svg>`;
            
            const d = a.createElement("pre");
            d.innerText = inputVal;
            
            commandRow.appendChild(z);
            commandRow.appendChild(d);
            outputsDiv.appendChild(commandRow);
            
            // 2. Evaluate and append result
            let c = a.createElement("pre");
            let b = (0, ev)(inputVal);
            
            // Select formatting type
            if (rdo[0].checked) c.innerText = window.special.format(b, Number(is.value));
            else if (rdo[1].checked) c.innerText = JSON.stringify(b, undefined, Number(is.value));
            else c.innerText = String(b)
            
            // Indent result slightly so it shifts past the arrow
            c.style.marginLeft = "21px"; 
            outputsDiv.appendChild(c);
            
        } catch (e) {
            let b = a.createElement("pre");
            // e.stack provides full stack info, but e.message is cleaner for quick views
            b.innerText = `Uncaught ${e.stack}`;
            b.style.backgroundColor = "#fcebeb";
            b.style.color = "#410e0b";
            b.style.marginLeft = "21px";
            outputsDiv.appendChild(b);
        }
        
        it.value = "";
        it.focus();
        
        // Auto-scroll outputs down as new logs print
        outputsDiv.scrollTop = outputsDiv.scrollHeight;
    });
    
    cc.addEventListener("click", function () {
        op.replaceChildren();
    });
})();